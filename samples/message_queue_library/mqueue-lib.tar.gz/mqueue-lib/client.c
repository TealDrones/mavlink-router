/*
** client.c -- reads from a message queue
** g++ client.c mqueue.c -o client
*/
#include <stdio.h>
#include <stdlib.h>
#include "mqueue.h"

int main(void)
{
	mqueue client;

	client.set_queue_name("gimbal.msg");
	int msqid = client.start(false);
	printf("Ready to receive messages\n");

	for(;;) {

		struct msgbuffer buf = client.get_buffer();
		if (!client.read(msqid, &buf, sizeof buf.mtext)) {
			printf("Unable to read from mqueue server, stopping client.\n");
			break;
		}
		else if (buf.mtext[0] != 0) {
			/* Print message */
			printf("Message received: \"%s\"\n", buf.mtext);
		}
		
		/* Checking for messages each 10 milliseconds */
		usleep(10000);
	}

	return 0;
}
